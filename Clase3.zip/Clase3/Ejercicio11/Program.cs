﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio11
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int promedio = 0, numIngresado=0, acumulador = 0, numMin = 0, numMax = 0, flag = 1, contador=0;

            for (int i=0 ; i < 10; i++)
            {

                Console.WriteLine("Ingrese un numero:");
                numIngresado = Convert.ToInt16(Console.ReadLine());

                if (Validacion.Validar(numIngresado, -100, 100))
                {
                    if (numMin > numIngresado || flag == 1)
                    {
                        numMin = numIngresado;
                        flag = 0;
                    }
                    if (numMax < numIngresado || flag == 1)
                    {
                        numMax = numIngresado;
                        flag = 0;
                    }
                    acumulador = acumulador + numIngresado;
                    contador++;
                }
                else
                {
                    Console.WriteLine("Erro.El numero ingresado no cumple con las condiciones.");
                }
            }

            promedio = acumulador / contador;

           Console.WriteLine("Valor minimo ingresado:{0}\n Valor maximo ingresado:{1}\n Promedio:{2}", numMin, numMax, promedio);


          Console.ReadKey();

        }
    }
}

public class Validacion
{
    public static bool Validar(int valor, int min, int max)
    {
        if (valor <= max && valor >= min)
        {s
            return true;
        }
        else
        {
            return false;
        }
    }
}


