﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiCalculadora
{
    public partial class FormCalculadora : Form
    {
        public FormCalculadora()
        {
            InitializeComponent();
        }

        private void FormCalculadora_Load(object sender, EventArgs e)
        {

        }

        private void ButCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ButLimpiar_Click(object sender, EventArgs e)
        {
            FormCalculadora.
        }

        private void ComboBoxOperador_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBoxOperador.Items.Add("+");
            ComboBoxOperador.Items.Add("-");
            ComboBoxOperador.Items.Add("/");
            ComboBoxOperador.Items.Add("*");
        }

        private void textDividendo_TextChanged(object sender, EventArgs e)
        {

        }

        private void ButOperar_Click(object sender, EventArgs e)
        {
          // Numero num1=textDividendo.Text, num2 = textDivisor.Text;


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
