using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MiCalculadora
{
    public partial class FormCalculadora : Form
    {
        public FormCalculadora()
        {
            InitializeComponent();
        }

        private void FormCalculadora_Load(object sender, EventArgs e)
        {

        }

        private void ButCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ButLimpiar_Click(object sender, EventArgs e)
        {
          textDividendo.Text= " ";
           textDivisor.Text= " ";
             ComboBoxOperador.Text = " ";
          
        }

        private void ComboBoxOperador_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void textDividendo_TextChanged(object sender, EventArgs e)
        {
  
         
         
        }

        private void ButOperar_Click(object sender, EventArgs e)
        {
          
          double resultado = Entidades.Calculadora.Operar(this.textDividendo.Text, this.textDivisor, ComboBoxOperador.Text);
          label1.Text = resultado.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {
     
        }

    private void textDivisor_TextChanged(object sender, EventArgs e)
    {
      /*Numero divisor = new Numero();*/
      Entidades.Numero.SteNumero(textDividendo.Text);//pasar esto a metodo operar, los text no tienen ninguna logica adentro.

    }

    private void ButBinario_Click(object sender, EventArgs e)
    {
      Entidades.Numero.DecimalBinario(label1.Text);
    }

    private void ButDecimal_Click(object sender, EventArgs e)
    {
      string a= Entidades.Numero.BinarioDecimal(label1.Text);

    }
  }
}
