using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MiCalculadora
{
    public partial class FormCalculadora : Form
    {
        public FormCalculadora()
        {
            InitializeComponent();
        }



        private void FormCalculadora_Load(object sender, EventArgs e)
        {

        }



        private void ButCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }



        private void ButLimpiar_Click(object sender, EventArgs e)
        {

            textDividendo.Text= " ";
            textDivisor.Text= " ";
            ComboBoxOperador.Text = " ";
          
        }



        private void ComboBoxOperador_SelectedIndexChanged(object sender, EventArgs e)
        {
        }



        private void textDividendo_TextChanged(object sender, EventArgs e)
        {     
        }



        /// <summary>
        /// se recibe el contenido de "txtNumero1", "txtNumero2" y "cmbOperador" y se los usa como parametros para el metodo "Calculadora.Operar".
        /// </summary>
        /// <param name="Numero1"></param>
        /// <param name="Numero2"></param>
        /// <param name="Operador"></param>
        /// <returns></returns>
        private static string Operar(string num1, string num2, string Operador)
        {
            Numero numeroUno, numeroDos;
            numeroUno = new Numero(num1);
            numeroDos = new Numero(num2);

            double resultado = Calculadora.Operar(numeroUno, numeroDos, Operador);
            return resultado.ToString();
        }



        private void ButOperar_Click(object sender, EventArgs e)
        {
           
          label1.Text = FormCalculadora.Operar(textDividendo.Text,textDivisor.Text, ComboBoxOperador.Text);

            if (ButBinario.Enabled == false || ButDecimal.Enabled == false)
            {
                ButBinario.Enabled = true;
                ButDecimal.Enabled = true;
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void textDivisor_TextChanged(object sender, EventArgs e)
        {
        }


        private void ButBinario_Click(object sender, EventArgs e)
        {
            label1.Text = Entidades.Numero.DecimalBinario(label1.Text);
        }


        private void ButDecimal_Click(object sender, EventArgs e)
        {
            label1.Text= Entidades.Numero.BinarioDecimal(label1.Text);
        }
  }
}
