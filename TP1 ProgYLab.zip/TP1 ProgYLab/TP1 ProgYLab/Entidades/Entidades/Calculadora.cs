using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Calculadora
    {
        //Metodos.

           /** Valida que el operador sea +,-,* o /.
             * El parametro que resive es un string que contiene el operador.
             * Devuelve el operador si esta ok, de lo contrario delvuelve +. */
        private static string ValidarOperador(string operador)
        {
            if (operador == "+" || operador == "-" || operador == "/" || operador == "*")
            {
                return operador;
            }
            else
            {
                return "+";
            }
        }

          /** Realiza la operacion pasada por parametro(operador) con los parametros num1 y num2 del tipo Numero.
            * Recibe 3 operadores, 2 del tipo Numero y 1 del tipo string.
            * Devuelve el resultado de la operacion y si fuese una divicion entre 0 devuelve double.MinValue. */
        public static double Operar(Numero num1, Numero num2, string operador)
        {
            Numero a = new Numero(), b = new Numero();
            Entidades.Numero.SteNumero(a);
            Entidades.Numero.SteNumero(b);
            string valiOpe = ValidarOperador(operador);
            double resultado=0;

            switch (valiOpe)
            {
                case "+":
                           resultado= a + b;
                           break;
                case "-":
                           resultado = a - b;
                           break;
                case "/":
                            if(a == 0 || b == 0)
                            {
                               resultado = double.MinValue;
                            }
                            else
                            {
                               resultado = a / b;
                            }
                           break;
                case "*":
                            resultado= a * b;
                           break;
            }

            return resultado;

        }
            

    }
}
