﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Numero
    {   
        // Atributos.
        private double numero;

        // Metodos.
        /* Comprueba que el valor recibido sea numerico.
         * recibe un string
         * Retorna el valor recibido por parametro con formato double si esta todo ok, de lo contrario retorna 0.
         */
        public double ValidarNumero(string strNumero)
        {
            bool n;
            double resultado = 0;
            if (n = double.TryParse(strNumero))
            {
                resultado = strNumero;
            }
            else
            {
                return resultado;
            }
        }

        /* Asigna un valor al atributo privado numero, previamente validado.
         * Recibe por parametro un string.
         */
        public void SteNumero(string num)
        {
            double n = ValidarNumero(num);
            this.numero = n;
        }

        /*
         */
         public string BinarioDecimal(string num)
        {
            string error = "Valor invalido";
            char[] array = num.ToCharArray();
            // Invertido pues los valores van incrementandose de derecha a izquierda: 16-8-4-2-1
            Array.Reverse(array);
            int suma = 0;

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == '1')
                {
                    // Usamos la potencia de 2, según la posición
                    suma += (int)Math.Pow(2, i);
                }
                else if(array[i] == '0')
                {
                    continue;
                }
                else
                {
                    return error;
                }
            }
        }

        public string DecimalBinario(double num)
        {
            int n = int.Parse(num);
            string bin = "", error = "Valor invalido";

            while (true)
            {
                if ((n % 2) == 1)
                {
                    bin = "1" + bin;
                }
                else if ((n % 2 == 0))
                {
                    bin = "0" + bin;
                }
                else
                {
                    return error;
                }

                n /= 2;//Divido por dos al numero.

                if (n <= 0)
                {
                    break;
                }
            }

        public string DecimalBinario(string num)
        {
            int n = int.Parse(num);
            string bin = "", error = "Valor invalido";

            while (true)
            {
                if((n % 2) == 1)
                {
                    bin = "1" + bin;
                }
                else if((n % 2 == 0))
                {
                    bin = "0" + bin;
                }
                else
                {
                    return error;
                }

                    n /= 2;//Divido por dos al numero.

                if(n <= 0)
                {
                    break;
                }
            }
            
        }

    }
}
