using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    class Estante
    {   //Atributos.
        private int ubicacionEstante;
        private Producto[] productos;

        //Constructor privado, inicializa el array de productos.
        private Estante(int capacidad)
        {
           this.productos = new Producto[capacidad];
        }
        /*Contructor publico, inicializa la ubicacion de estante
        y por medio de ella se llama al contructor privado para inicializar el array de productos.*/
        public Estante(int capacidad, int ubicacion): this(capacidad)
        {
            this.ubicacionEstante = ubicacion;
        }

        //Metordos
        public Producto[] GetProductos()
        {
            return this.productos; /*El m�todo p�blico GetProductos, retornar� el array de productos.*/
        }

        public string MostrarEstante(Estante e)
        {
            StringBuilder cadena= new StringBuilder();
            //cadena.Append("Estante: ");
            //cadena.AppendLine(this.ubicacionEstante.ToString());
            cadena.AppendFormat("Estante: {0}\n", this.ubicacionEstante);
            foreach (Producto p in e.productos)
            {
                cadena.AppendLine();
            }

            return cadena.ToString();

        }

    }
}
