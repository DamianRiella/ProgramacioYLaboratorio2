using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    class Producto
    {
        //Atributos privados.
        private string codigoDeBarra, marca;
        private double precio;

        //Contructor.
        public Producto()
        {
            codigoDeBarra = "adi549862";
            marca = "adidas";
            precio = 10;
        }

        //Metodos.
        public string GetMarca()
        {
            return marca; //Retorna la marca.
        }
        public double GetPrecio()
        {
            return precio; //Retorna el precio.
        }
        public static string MostrarProducto(Producto p)
        {
            string n = "Marca:" + p.marca + " Precio:" + p.precio + " Codigo:" + p.codigoDeBarra; //Combierte los atributos del objeto a string y lo devuelve en forma de cadena.

            return n;
        }

        //Sobre carga de operadores.
        public static explicit operator  string(Producto p)
        {
            return p.codigoDeBarra; //Retorna el codigo del objeto pasado por parametro.
        }

        /*Compara un string del atributo marca, pasado por parametro, con el atributo marca de un objeto pasado por parameto. 
         */ 
        public static bool operator == (Producto p, string marca)
        {
            if(p.marca == marca)
            {
                return true; //Si se cumple la condicion debuelve true.
            }
            else
            {
                return false; //Si no se cumple devuelve false.
            }
        }

        public static bool operator !=(Producto p, string marca)
        {
            return !(p.marca == marca); // Verifica si los atributos de los parametros son distintos, si es asi devuelve true.
        }

        /* Compara dos atributos deobjetos pasados por parametro, si se cumple la condicion devuelve true, de lo contrario false.
         */
        public static bool operator ==(Producto p1, Producto p2)
        {
            if(p1.marca == p2.marca && p1.codigoDeBarra == p2.codigoDeBarra)
            {
                return true; //Si se cumple la condicion debuelve true.
            }
            else
            {
                return false; //Si no se cumple devuelve false.
            }
        }

        public static bool operator !=(Producto p1, Producto p2)
        {
            return !(p1.marca == p2.marca); // Verifica si los atributos de los parametros son distintos, si es asi devuelve true.
        }




    }
}
