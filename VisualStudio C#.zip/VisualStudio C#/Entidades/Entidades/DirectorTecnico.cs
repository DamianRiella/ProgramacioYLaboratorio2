﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DirectorTecnico : Persona
    {
        #region Atributos 
         int añosExperiencia;
        #endregion

        #region Propiedades
        public int AñosExperiencia
        {
            get
            {
                return añosExperiencia;
            }
            set
            {
                añosExperiencia = value;
            }
        }
        #endregion

        #region Contructores
        public DirectorTecnico(string nombre, string apellido, int edad, int dni, int añosExperiencia)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.edad = edad;
            this.dni = dni;
            this.añosExperiencia = añosExperiencia;

        }
        #endregion

        #region Metodos
        public override bool ValidarAptitud()
        {
            bool retorno = false;

            if(this.edad<65 && this.añosExperiencia>=2)
            {
                retorno = true;
            }
            return retorno;
        }

        public override string Mostrar()
        {
            StringBuilder retorno;
            retorno = new StringBuilder();

            retorno.Append(string.Format("{0}", base.Mostrar()));
            retorno.Append(string.Format("Años de experiencia: {0}", this.AñosExperiencia));

            return retorno.ToString();
        }
        #endregion
    }
}
