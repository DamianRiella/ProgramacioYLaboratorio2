﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Jugador : Persona
    {
        #region Atributos
         float altura;
         float peso;
        Posicion posicion;
        #endregion

        #region Propiedades

        public float Altura
        {
            get
            {
                return altura;
            }
        }

        public float Peso
        {
            get
            {
                return peso;
            }
        }

        public Posicion Posicion
        {
            get
            {
                return posicion;
            }
        }  
        #endregion

        #region Contructores
        public Jugador(string nombre, string apellido, int edad, int dni, float altura, float peso, Posicion posicion)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.edad = edad;
            this.dni = dni;
            this.altura = altura;
            this.peso = peso;
            this.posicion = posicion;
        }
        #endregion

        #region Metodos
        public override bool ValidarAptitud()
        {
            bool retorno = false;
            if(this.edad<=40 && ValidadEstadoFisico()==true)
            {
                retorno = true;
            }
            return retorno;
        }

        public override string Mostrar()
        {
            StringBuilder retorno;
            retorno = new StringBuilder();

            retorno.Append(string.Format("{0}", base.Mostrar()));
            retorno.Append(string.Format("Altura: {0}", this.Altura));
            retorno.Append(string.Format("Peso: {0}", this.Peso));
            retorno.Append(string.Format("Posicion: {0}", this.Posicion));

            return retorno.ToString();
        }

        public bool ValidadEstadoFisico()
        {
           bool retorno = false;
           float imc, auxPeso= this.Peso, auxAltura= this.Altura;

            imc = (float)Math.Pow(2,auxPeso / auxAltura);

            if(imc>=18.5 && imc<=25)
            {
                retorno = true;
            }

            return retorno;
        }
        #endregion
    }
}
