﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Equipo
    {
        #region Atributos
        private const int cantidadMaximaJugadores = 6;
        private DirectorTecnico directorTecnico;
        private List<Jugador> jugadores;
        private string nombre;
        #endregion

        #region Propiedades
        public DirectorTecnico DirectorTecnico
        {
            set
            {
                directorTecnico = value;
            }
        }

        public string Nombre
        {
            get
            {
                return nombre;
            }
        }
        #endregion

        #region Constructor
        private Equipo()
        {
            jugadores = new List<Jugador>();
        }
        #endregion

        #region Metodos
        public static bool operator !=(Equipo e, Jugador j)
        {

        }
        public static Equipo operator +(Equipo e, Jugador j)
        {

        }
        public static bool operator ==(Equipo e, Jugador j)
        {
            foreach (Equipo.jugadores.)
            {

            }
        }
        public static explicit operator string(Equipo e)
        {

        }
        public private bool ValidarEquipo(Equipo e)
        {
            if (e.directorTecnico != null)
            {
                if()
            }
        }
    
        #endregion

    }
}
