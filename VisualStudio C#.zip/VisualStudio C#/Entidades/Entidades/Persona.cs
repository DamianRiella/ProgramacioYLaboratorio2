﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Persona
    {
        #region Atributos
        protected string apellido;
        protected string nombre;
        protected int edad;
        protected int dni;
        #endregion

        #region Propiedades

        public string Apellido
        {
            get
            {
                return apellido;
            }
        }
        public string Nombre
        {
            get
            {
                return nombre;
            }
        }
        public int Edad
        {
            get
            {
                return edad;
            }
        }
        public int Dni
        {
            get
            {
                return dni;
            }
        }
        #endregion

        #region Copnstructor
        public Persona(string nombre, string apellido, int edad, int dni)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.edad = edad;
            this.dni = dni;
        }
        #endregion

        #region Medtodos
        public virtual string Mostrar()
        {
        }
        public abstract bool ValidarAptitud();
        
        #endregion
    }
}
