﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Persona
    {
        #region Atributos
         protected  string apellido;
         protected string nombre;
         protected int edad;
         protected int dni;
        #endregion

        #region Propiedades

        public string Apellido
        {
            get
            {
                return apellido;
            }
        }
        public string Nombre
        {
            get
            {
                return nombre;
            }
        }
        public int Edad
        {
            get
            {
                return edad;
            }
        }
        public int Dni
        {
            get
            {
                return dni;
            }
        }
        #endregion

        #region Copnstructor
        public Persona(string nombre, string apellido, int edad, int dni)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.edad = edad;
            this.dni = dni;
        }
        #endregion

        #region Medtodos
        public virtual string Mostrar()
        {
            StringBuilder retorno;
            retorno = new StringBuilder();

                retorno.Append(string.Format("Nombre: {0}",this.Nombre));
                retorno.Append(string.Format("Apellido: {0}", this.Apellido));
                retorno.Append(string.Format("Edad: {0}", this.Edad));
                retorno.Append(string.Format("Dni: {0}", this.Dni));

            return retorno.ToString();

        }
        public abstract bool ValidarAptitud();
        
        #endregion
    }
}
